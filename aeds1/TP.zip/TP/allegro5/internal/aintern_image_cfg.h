#define ALLEGRO_CFG_WANT_NATIVE_IMAGE_LOADER

/* which libraries are present and needed? */
#define ALLEGRO_CFG_IIO_HAVE_GDIPLUS
/* #undef ALLEGRO_CFG_IIO_HAVE_GDIPLUS_LOWERCASE_H */
/* #undef ALLEGRO_CFG_IIO_HAVE_ANDROID */
/* #undef ALLEGRO_CFG_IIO_HAVE_PNG */
/* #undef ALLEGRO_CFG_IIO_HAVE_JPG */

/* which formats are supported and wanted? */
#define ALLEGRO_CFG_IIO_SUPPORT_PNG
#define ALLEGRO_CFG_IIO_SUPPORT_JPG
